package com.mycompany.digimon;
import java.util.*;
/**
 * 
 * @author Alberto
 */
/**
 * Clase que representa un Digimon con atributos como nombre, nivel, ataque, salud, y puntos de digievolución.
 */
public class Digimon {
    private final String nombre;
    private final int nivel;
    private final int ataque;
    private int salud;
    private int dp1;
    private int dp2;
    private boolean muerto;

    /**
     * Constructor que crea un Digimon con un nombre especificado.
     * El nivel del Digimon es generado aleatoriamente entre 1 y 5.
     * El ataque es calculado como 5 veces el nivel.
     * La salud es calculada como 10 veces el nivel.
     * 
     * @param nombre El nombre del Digimon.
     */
    public Digimon(String nombre) {
        this.nombre = nombre;
        Random rand = new Random();
        this.nivel = rand.nextInt(5) + 1; // Nivel entre 1 y 5
        this.ataque = 5 * nivel;
        this.salud = 10 * nivel;
        this.dp1 = 10;
        this.dp2 = 10;
        this.muerto = false;
    }

    /**
     * Obtiene el nombre del Digimon.
     * 
     * @return El nombre del Digimon.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el nivel del Digimon.
     * 
     * @return El nivel del Digimon.
     */
    public int getNivel() {
        return nivel;
    }

    /**
     * Obtiene el valor de ataque del Digimon.
     * 
     * @return El ataque del Digimon.
     */
    public int getAtaque() {
        return ataque;
    }

    /**
     * Obtiene la salud actual del Digimon.
     * 
     * @return La salud del Digimon.
     */
    public int getSalud() {
        return salud;
    }

    /**
     * Obtiene los puntos de digievolución (DP1) restantes del Digimon.
     * 
     * @return Los puntos de digievolución DP1.
     */
    public int getDp1() {
        return dp1;
    }

    /**
     * Obtiene los puntos de digievolución (DP2) restantes del Digimon.
     * 
     * @return Los puntos de digievolución DP2.
     */
    public int getDp2() {
        return dp2;
    }

    /**
     * Verifica si el Digimon está muerto.
     * 
     * @return {@code true} si el Digimon está muerto, {@code false} en caso contrario.
     */
    public boolean isMuerto() {
        return muerto;
    }

    /**
     * Establece la salud del Digimon. Si la salud es menor o igual a 0, el Digimon se marca como muerto.
     * 
     * @param salud La nueva salud del Digimon.
     */
    public void setSalud(int salud) {
        this.salud = salud;
        if (this.salud <= 0) {
            this.muerto = true;
            this.salud = 0;
        }
    }

    /**
     * El Digimon usa su Ataque1 sobre un Digimon enemigo. 
     * Disminuye la salud del enemigo en la cantidad del ataque del Digimon.
     * Disminuye los puntos de digievolución DP1 en 1.
     * 
     * @param enemigo El Digimon enemigo que recibe el ataque.
     * @throws IllegalStateException Si el Digimon no tiene suficientes DP para usar el ataque.
     */
    public void usarAtaque1(Digimon enemigo) {
        if (dp1 > 0) {
            enemigo.setSalud(enemigo.getSalud() - ataque);
            dp1--;
        } else {
            System.out.println(nombre + " no tiene suficientes DP para Ataque1");
        }
    }

    /**
     * El Digimon usa su Ataque2 sobre un Digimon enemigo. 
     * Disminuye la salud del enemigo en el doble del ataque del Digimon.
     * Disminuye los puntos de digievolución DP2 en 2.
     * 
     * @param enemigo El Digimon enemigo que recibe el ataque.
     * @throws IllegalStateException Si el Digimon no tiene suficientes DP para usar el ataque.
     */
    public void usarAtaque2(Digimon enemigo) {
        if (dp2 > 1) {
            enemigo.setSalud(enemigo.getSalud() - 2 * ataque);
            dp2 -= 2;
        } else {
            System.out.println(nombre + " no tiene suficientes DP para Ataque2");
        }
    }
}