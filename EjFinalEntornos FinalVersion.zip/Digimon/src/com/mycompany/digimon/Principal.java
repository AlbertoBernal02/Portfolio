package com.mycompany.digimon;
import java.util.*;
/**
 * Clase principal que inicia la aplicación de Digimon.
 * Permite al usuario iniciar una batalla o salir del programa.
 * 
 * @author Alberto
 */
public class Principal {
    /**
     * El método principal que inicia la ejecución del programa.
     * 
     * @param args Los argumentos de la línea de comandos.
     * @throws InputMismatchException Si la entrada del usuario no es un número válido.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del domador:");
        String nombreDomador = scanner.nextLine();
        Domador domador = new Domador(nombreDomador);

        OUTER:
        while (true) {
            System.out.println("1. Iniciar batalla");
            System.out.println("2. Salir");
            int opcion = scanner.nextInt();
            switch (opcion) {
                case 1 -> {
                    BatallaDigital batalla = new BatallaDigital();
                    batalla.elige(domador);
                }
                case 2 -> {
                    break OUTER;
                }
                default -> System.out.println("Opción no válida.");
            }
        }
    }
}