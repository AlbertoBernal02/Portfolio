package com.mycompany.digimon;
import java.util.*;
/**
 * Clase que representa un Domador, que tiene un equipo de Digimons.
 * 
 * @author Alberto
 */
public class Domador {
    private final String nombre;
    private final List<Digimon> equipo;

    /**
     * Constructor que crea un Domador con un nombre especificado.
     * Inicializa el equipo con tres Digimons: Agumon, Gabumon y Patamon.
     * 
     * @param nombre El nombre del Domador.
     */
    public Domador(String nombre) {
        this.nombre = nombre;
        this.equipo = new ArrayList<>();
        equipo.add(new Digimon("Agumon"));
        equipo.add(new Digimon("Gabumon"));
        equipo.add(new Digimon("Patamon"));
    }

    /**
     * Obtiene el nombre del Domador.
     * 
     * @return El nombre del Domador.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la lista de Digimons en el equipo del Domador.
     * 
     * @return La lista de Digimons en el equipo.
     */
    public List<Digimon> getEquipo() {
        return equipo;
    }

    /**
     * Intenta capturar un Digimon y añadirlo al equipo del Domador.
     * Un Digimon solo puede ser capturado si su salud es menor a 20 y el equipo del Domador tiene menos de 3 Digimons.
     * 
     * @param digimon El Digimon a capturar.
     * @throws IllegalStateException Si el Digimon no puede ser capturado.
     */
    public void capturar(Digimon digimon) {
        if (digimon.getSalud() < 20 && equipo.size() < 3) {
            equipo.add(digimon);
            System.out.println(digimon.getNombre() + " se ha unido a su equipo.");
        } else {
            System.out.println("No se puede unir.");
            throw new IllegalStateException("No se puede unir.");
        }
    }
}
